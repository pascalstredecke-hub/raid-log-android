# RAID//LOG – Android APK-Projekt

Dieses Android-Studio-Projekt verpackt die RAID//LOG-Web-App in eine installierbare Android-App mit WebView. Die HTML-Datei wird lokal aus der App geladen; die App benötigt für die enthaltenen Funktionen keine Internetverbindung. Lokal gespeicherte App-Daten bleiben auf dem Gerät.

## APK erstellen

1. Android Studio installieren (https://developer.android.com/studio).
2. Android Studio öffnen und **Open** wählen. Den entpackten Ordner `RAID_LOG_Android_APK_Project` auswählen.
3. Warten, bis Gradle synchronisiert ist. Falls Android Studio danach fragt, Android SDK Platform 35 installieren.
4. Menü **Build → Build Bundle(s) / APK(s) → Build APK(s)** auswählen.
5. Die APK liegt nach erfolgreichem Build üblicherweise unter `app/build/outputs/apk/debug/app-debug.apk`.
6. APK auf das Android-Tablet übertragen und öffnen. Gegebenenfalls die Installation aus dieser Quelle in Android erlauben.

## Hinweise

- Dies ist der Quellcode eines APK-fähigen Android-Projekts, keine bereits kompilierte APK.
- Für ein Release sollte eine eigene signierte APK erstellt werden.
- Die Spielinhalte und die schematische Karte sind Beispielinhalte, keine verifizierten offiziellen ARC-Raiders-Daten.
- Kein offizielles Produkt von Embark Studios.
